#include "sys.h"

//static void IIC_SDA_OUT()
//{
//	GPIO_InitTypeDef	GPIO_InitStructure;
//	
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
//  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
//  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_OD;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
//}

//static void IIC_SDA_IN()
//{
//	GPIO_InitTypeDef	GPIO_InitStructure;
//	
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
//  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
//  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
//}

static int freqCnt=1;


void MLX90640_I2CInit()
{   
    I2CStop();
}

int MLX90640_I2CRead(uint8_t slaveAddr, uint16_t startAddress,uint16_t nMemAddressRead, uint16_t *data)
{
    uint8_t sa;
    int ack = 0;
    int cnt = 0;
    int i = 0;
		
    char cmd[2] = {0,0};
    char i2cData[1664] = {0};
    uint16_t *p;
    
    p = data;
    sa = (slaveAddr << 1);
    cmd[0] = startAddress >> 8;
    cmd[1] = startAddress & 0x00FF;
		
//    I2CStop();
//    Wait(freqCnt);  
    I2CStart();
    Wait(freqCnt);
    
    ack = I2CSendByte(sa)!=0;
    if(ack != 0)
    {
        return -1;
    } 
    
    ack = I2CSendByte(cmd[0])!=0;   
    if(ack != 0)
    {
        return -1;
    }   
    
    ack = I2CSendByte(cmd[1])!=0;    
    if(ack != 0)
    {
        return -1;
    }      
		
    I2CStart();
       
    sa = sa | 0x01;
    
    ack = I2CSendByte(sa);
    if(ack != 0)
    {
        return -1;
    }
        
    I2CReadBytes((nMemAddressRead << 1), i2cData);
              
    I2CStop();   
		
    for(cnt=0; cnt < nMemAddressRead; cnt++)
    {
        i = cnt << 1;
        *p++ = (int)i2cData[i]*256 + (int)i2cData[i+1];
    } 
    return 0;
  
} 

void MLX90640_I2CFreqSet(int freq)
{
    freqCnt = freq>>1;
}

int MLX90640_I2CWrite(uint8_t slaveAddr, uint16_t writeAddress, uint16_t data)
{
    uint8_t sa;
    int ack = 0;
    char cmd[4] = {0,0,0,0};
//    u16 dataCheck;
	int i;

    sa = (slaveAddr << 1);
    cmd[0] = writeAddress >> 8;
    cmd[1] = writeAddress & 0x00FF;
    cmd[2] = data >> 8;
    cmd[3] = data & 0x00FF;

//    I2CStop();
//    Wait(freqCnt);
    I2CStart();
    ack = I2CSendByte(sa);
    if (ack != 0x00)
    {
      I2CStop();  
			return 1; 
    } 
    
    for(i = 0; i<4; i++)
    {
       ack = I2CSendByte(cmd[i]);
    
        if (ack != 0x00)
        {
          I2CStop();   
					return -1;
        }          
    }           
    I2CStop();  

//    MLX90640_I2CRead(slaveAddr,writeAddress,1, &dataCheck);
//    
//    if ( dataCheck != data)
//    {
//        return -2;
//    }    
    
    return 0;
}

int I2CSendByte(int8_t data)
{
   int ack = 1;
   int8_t byte = data; 
   int i;

//   IIC_SDA_OUT();
   for(i=0;i<8;i++)
   {     
       if(byte & 0x80)
       {
           SDA_HIGH;
       }
       else
       {
           SDA_LOW;
       }
       Wait(freqCnt);
       SCL_HIGH;
       Wait(freqCnt);
       SCL_LOW;
			 if (i == 7)
			 {
					SDA_HIGH; // �ͷ�����
			 }	
       byte = byte<<1;
			 Wait(freqCnt);			 
   }
	 
	 ack = I2CReceiveAck();   
   return ack;
}

void I2CReadBytes(int nBytes, char *dataP)
{
  char data;
	int i,j;

//	IIC_SDA_IN();
    for(j=0;j<nBytes;j++)
    {         
        data = 0;
        for(i=0;i<8;i++)
				{
            data <<= 1;
						SCL_HIGH;
//            Wait(freqCnt);
					 __NOP();__NOP();
            if(sda != 0){
                data++;  
            }
            SCL_LOW;
 //           Wait(freqCnt);
						__NOP();__NOP();
        }  
        
        if(j == (nBytes-1))
        {
            I2CSendNack();
        }
        else
        {                  
            I2CSendACK();
        }
            
        *(dataP+j) = data; 
    }
	    
//    IIC_SDA_OUT();
}
     
void Wait(int freqCnt)
{
#if 0
    int i,TimeCnt;
    for( i = 0; i<freqCnt; i++)
    {
        TimeCnt ++; 
    }    
#endif
	
} 

void I2CStart(void)
{
//	IIC_SDA_OUT();
    SDA_HIGH;
    SCL_HIGH;
    Wait(freqCnt);
    SDA_LOW;
    Wait(freqCnt);
    SCL_LOW;
    Wait(freqCnt);    
    
}

void I2CStop(void)
{
//	IIC_SDA_OUT();    
    SDA_LOW;
		SCL_HIGH;
    Wait(freqCnt);
    SDA_HIGH;
}

void I2CSendACK(void)
{
//	IIC_SDA_OUT();
    SDA_LOW;
    Wait(freqCnt);
    SCL_HIGH;
    Wait(freqCnt);
    SCL_LOW;
    Wait(freqCnt);
    SDA_HIGH; 
}

void I2CSendNack(void)
{
//	IIC_SDA_OUT();
    SDA_HIGH;
    Wait(freqCnt);
    SCL_HIGH;
    Wait(freqCnt);
    SCL_LOW;
    Wait(freqCnt);  
}  

int I2CReceiveAck(void)
{
    int ack;
    
//	IIC_SDA_IN();
		SDA_HIGH;
		Wait(freqCnt);
    SCL_HIGH;
    Wait(freqCnt);
    if(sda == 0)
    {
        ack = 0;
    }
    else
    {
        ack = 1;
    }  	
//		IIC_SDA_OUT();     
    SCL_LOW;
		Wait(freqCnt);
   
    return ack;    
} 
