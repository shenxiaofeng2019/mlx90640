#ifndef __USART2_H
#define	__USART2_H

#include "stm32f10x.h"
#include <stdio.h>

#define  BOUNDRATE 460800

#define UART2_BUFF_SIZE 10

extern u8 Uart2_buffer_Rx[];
extern u8 command_flag;//�յ������ݵ�������
extern u8 data_flag[];

//extern void usart2_init(void);
extern void uart2_send_byte(uint8_t byte);
extern void clean_rebuff2(void);
extern void data_rec_server (void);

extern void computchar(USART_TypeDef* USARTx,u8 ch);
extern void computstr(USART_TypeDef* USARTx,u8 *ptr,u16 len);
extern void computcstr(USART_TypeDef* USARTx,const char *ptr);

#endif /* __BSP_USART_H */










