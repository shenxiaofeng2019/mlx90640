#include "sys.h"
#include "usart2.h"
#include "bsp_ds18b20.h"
#include "bsp_SysTick.h"
#include "eeprom.h"

#define LSIFREQ 40000

#define IR_LED_ON GPIOC->BSRR=GPIO_Pin_0
#define IR_LED_OFF GPIOC->BRR=GPIO_Pin_0

#define STM_LED_ON GPIOB->BRR=GPIO_Pin_14
#define STM_LED_OFF GPIOB->BSRR=GPIO_Pin_14

//#define STM_ON GPIOA->BRR=GPIO_Pin_10
//#define STM_OFF GPIOA->BSRR=GPIO_Pin_10

u32 SN = 1;
static const char soft_version[10] = "FW_V1.0.0 ";//"MSOFT_V1.0";
static const char firmware_information[10] = "HW_V1.0.0 ";//"1111111111";

/* Virtual address defined by the user: 0xFFFF value is prohibited */
uint16_t VirtAddVarTab[NumbOfVar] = {0x1110,0x1111};
uint8_t baudRateValueIndex;
uint8_t RefreshRateValueIndex;

#define BAUDINDEX 6
#define REFRESHINDEX 5
	
#define EEPROM_START_ADDR		0x1110
#define ADDR_BAUD_SET						( EEPROM_START_ADDR )
#define ADDR_REFRESH_SET				( EEPROM_START_ADDR + 1 )

frmFmt frmfmt;
u8 receive_flag = 0;

#define  Rate2HZ   0x02
#define  Rate4HZ   0x03
#define  Rate8HZ   0x04
#define  Rate16HZ  0x05
#define  Rate32HZ  0x06

#define  MLX_I2C_ADDR 0x33
//#define	 RefreshRate Rate16HZ 
#define  TA_SHIFT 8 //Default shift for MLX90640 in open air

uint16_t eeMLX90640[832];  
uint16_t frame[834];
paramsMLX90640 mlx90640; 

static void response_basic_info()
{
	u8 i;
	u16 len = 24;
	u8 cmd_dat[30] = {0x23,0x23,0x80};
	cmd_dat[3] = (len>>8)&0xff;
	cmd_dat[4] = len&0xff;
	cmd_dat[5] = (SN>>24)&0xff;
	cmd_dat[6] = (SN>>16)&0xff;
	cmd_dat[7] = (SN>>8)&0xff;
	cmd_dat[8] = (SN)&0xff;
	for(i=0;i<10;i++) cmd_dat[9+i] = soft_version[i];
	for(i=0;i<10;i++) cmd_dat[19+i] = firmware_information[i];
	cmd_dat[29] = cmd_dat[2];
	for(i=0;i<26;i++) cmd_dat[29] ^= cmd_dat[3+i];
	
	for(i=0;i<30;i++) uart2_send_byte(cmd_dat[i]);
}

static void response_led_on(u8 status)//0x01:success,0x02:fail
{
	u8 i;
	u8 cmd_dat[7] = {0x23,0x23,0x82,0x00,0x01,0x01,0x00};
	cmd_dat[5] = status;
	cmd_dat[6] = cmd_dat[2];
	cmd_dat[6] ^= cmd_dat[3];
	cmd_dat[6] ^= cmd_dat[4];
	cmd_dat[6] ^= cmd_dat[5];
	
	for(i=0;i<7;i++) uart2_send_byte(cmd_dat[i]);
}

static void response_led_off(u8 status)//0x01:success,0x02:fail
{
	u8 i;
	u8 cmd_dat[7] = {0x23,0x23,0x83,0x00,0x01,0x01,0x00};
	cmd_dat[5] = status;
	cmd_dat[6] = cmd_dat[2];
	cmd_dat[6] ^= cmd_dat[3];
	cmd_dat[6] ^= cmd_dat[4];
	cmd_dat[6] ^= cmd_dat[5];
	
	for(i=0;i<7;i++) uart2_send_byte(cmd_dat[i]);
}

static void gpio_init()
{
	GPIO_InitTypeDef	GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD,ENABLE);
	RCC_APB1PeriphClockCmd(	RCC_APB1Periph_USART2, ENABLE );	

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
  GPIO_Init(GPIOC, &GPIO_InitStructure);	
	IR_LED_OFF;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);	
	STM_LED_OFF;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_OD;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
//  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
//  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA,&GPIO_InitStructure);
}

uint32_t GetRefreshRate( uint8_t refresh )
{
	uint32_t refreshVal;

	switch( refresh )
	{
		case 2:
			refreshVal = Rate2HZ;
			break;	
		case 3:
			refreshVal = Rate4HZ;
			break;
		case 4:
			refreshVal = Rate8HZ;
			break;	
		case 5:
			refreshVal = Rate16HZ;
			break;
		case 6:
			refreshVal = Rate32HZ;
			break;
		default:
 			refreshVal = Rate8HZ;
 			RefreshRateValueIndex = 4;
 		break;	
	}
	return( refreshVal );			
}

void ChangeMLX90640RefreshRate( uint8_t refresh )
{
	
	uint32_t refreshRateVal;
	
	RefreshRateValueIndex = refresh;
	
	refreshRateVal = GetRefreshRate( RefreshRateValueIndex );
	
	MLX90640_SetRefreshRate(MLX_I2C_ADDR, refreshRateVal);
}

uint32_t GetBaudRate( uint8_t baud )
{
	uint32_t baudVal;

	switch( baud )
	{
		case 1:
			baudVal = 9600;
			break;
		case 2:
			baudVal = 19200;
			break;	
		case 3:
			baudVal = 38400;
			break;
		case 4:
			baudVal = 57600;
			break;	
		case 5:
			baudVal = 115200;
			break;
		case 6:
			baudVal = 460800;
			break;
		default:
 			baudVal = 115200;
 			baudRateValueIndex = 5;
 		break;	
	}
	return( baudVal );			
}

void sysUARTHardwareInit( void )
{
	USART_InitTypeDef USART_InitStructure;
	uint32_t baudVal;
	
	baudVal = GetBaudRate( baudRateValueIndex );
	
	USART_InitStructure.USART_BaudRate = baudVal;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2, &USART_InitStructure);

 	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

  USART_Cmd(USART2, ENABLE);
}

void ChangeUSARTBaudRate( uint8_t baud )
{
  USART_Cmd(USART2, DISABLE);
	
	baudRateValueIndex = baud;

	USART_DeInit( USART2 );

	sysUARTHardwareInit();
}

static void response_ir_data()
{
	int i,m;
	u8 line;
#if 0
	u16 len = 1668;//0x0684
	u8 cmd_dat[1674] = {0x23,0x23,0x84};
	cmd_dat[3] = (len>>8)&0xff;
	cmd_dat[4] = len&0xff;
	for(i=0;i<834;i++)
	{
		cmd_dat[5+2*i] = (frame[i]>>8)&0xff;
		cmd_dat[5+2*i+1] = frame[i]&0xff;
	}
	
	cmd_dat[1673] = cmd_dat[2];
	for(i=0;i<1670;i++) cmd_dat[1673] ^= cmd_dat[3+i];
	for(i=0;i<1674;i++) uart2_send_byte(cmd_dat[i]);
#endif

#if 0
	
	u16 len = 900;//768+128+4+1
	u8 cmd_dat[907] = {0x23,0x23,0x86};//5+768+128+4+1
	cmd_dat[3] = (len>>8)&0xff;
	cmd_dat[4] = len&0xff;
//	for(i=0;i<5;i++) 
//	{
//		uart2_send_byte(cmd_dat[i]);
//	}
	
//	cmd_dat[905] = cmd_dat[2];
//	cmd_dat[905] ^= cmd_dat[3];
//	cmd_dat[905] ^= cmd_dat[4];
	
	if(frame[833] == 0)
	{
//		for(i=0;i<384;i++)
//		{
//			cmd_dat[(i<<1)+5] = (frame[i<<1]>>8)&0xff;
//			uart2_send_byte(cmd_dat[(i<<1)+5]);
//			cmd_dat[(i<<1)+6] = frame[i<<1]&0xff;
//			uart2_send_byte(cmd_dat[(i<<1)+6]);
//			
//			cmd_dat[905] ^= cmd_dat[(i<<1)+5];
//			cmd_dat[905] ^= cmd_dat[(i<<1)+6];
//	  }
		 m=5;
	  for(line=0;line<24;line++)
		{
			if((line+2)%2==0)
			{	
				for(i=0;i<32;i=i+2)
				{
				 cmd_dat[m] =(frame[(line*32)+i]>>8)&0xff;
				 m++;	
				 cmd_dat[m] =frame[(line*32)+i]&0xff;	
				 m++;	
				}
			}	
			if((line+2)%2==1)
			{	
				for(i=0;i<32;i=i+2)
				{
				 cmd_dat[m] =(frame[(line*32)+1+i]>>8)&0xff;
				 m++;	
				 cmd_dat[m] =frame[(line*32)+1+i]&0xff;	
				 m++;	
				}
			}	
		}
			
//			cmd_dat[905] ^= cmd_dat[(i<<1)+5];
//			cmd_dat[905] ^= cmd_dat[(i<<1)+6];
	 } 
		


	else if(frame[833] == 1)
	{
//		for(i=0;i<384;i++) 
//		{
//			cmd_dat[(i<<1)+5] = (frame[1+(i<<1)]>>8)&0xff;
//			uart2_send_byte(cmd_dat[(i<<1)+5]);
//			cmd_dat[(i<<1)+6] = frame[1+(i<<1)]&0xff;
//			uart2_send_byte(cmd_dat[(i<<1)+6]);
//			
//			cmd_dat[905] ^= cmd_dat[(i<<1)+5];
//			cmd_dat[905] ^= cmd_dat[(i<<1)+6];

//		}
	  m=5;
	  for(line=0;line<24;line++)
		{
				
			if((line+2)%2==0)
			{	
				for(i=0;i<32;i=i+2)
				{
				 cmd_dat[m] =(frame[(line*32)+1+i]>>8)&0xff;
				 m++;	
				 cmd_dat[m] =frame[(line*32)+1+i]&0xff;	
				 m++;	
				}
			}
     if((line+2)%2==1)
			{	
				for(i=0;i<32;i=i+2)
				{
				 cmd_dat[m] =(frame[(line*32)+i]>>8)&0xff;
				 m++;	
				 cmd_dat[m] =frame[(line*32)+i]&0xff;	
				 m++;	
				}
			}			
		}	
		
		
	}
//	else
//	{
//		for(i=0;i<384;i++) 
//		{
//			cmd_dat[(i<<1)+5] = 0;
//			cmd_dat[(i<<1)+6] = 0;
//			
//			cmd_dat[905] ^= cmd_dat[(i<<1)+5];
//			uart2_send_byte(cmd_dat[(i<<1)+5]);
//			cmd_dat[905] ^= cmd_dat[(i<<1)+6];
//			uart2_send_byte(cmd_dat[(i<<1)+6]);
//		}
//	}
	
	for(i=768;i<834;i++)
	{
		cmd_dat[((i-768)<<1)+773] = (frame[i]>>8)&0xff;//1541+i-768
//		uart2_send_byte(cmd_dat[((i-768)<<1)+773]);
		cmd_dat[((i-768)<<1)+774] = frame[i]&0xff;
//		uart2_send_byte(cmd_dat[((i-768)<<1)+774]);
		
//		cmd_dat[905] ^= cmd_dat[((i-768)<<1)+773];
//		cmd_dat[905] ^= cmd_dat[((i-768)<<1)+774];
	}
	
	cmd_dat[905] = cmd_dat[2];
	for(i=0;i<902;i++) cmd_dat[905] ^= cmd_dat[3+i];
	for(i=0;i<906;i++) uart2_send_byte(cmd_dat[i]);
// computstr( USART2,cmd_dat,906);//�������ݵ�����2

#endif

#if 1 
	u16 len = 902;//768+128+4+2+1
	u8 cmd_dat[908] = {0x23,0x23,0x86};//5+768+128+4+2+1
	cmd_dat[3] = (len>>8)&0xff;
	cmd_dat[4] = len&0xff;
	
	if(frame[833] == 0)
	{
		 m=5;
	  for(line=0;line<24;line++)
		{
			if((line+2)%2==0)
			{	
				for(i=0;i<32;i=i+2)
				{
				 cmd_dat[m] =(frame[(line*32)+i]>>8)&0xff;
				 m++;	
				 cmd_dat[m] =frame[(line*32)+i]&0xff;	
				 m++;	
				}
			}	
			if((line+2)%2==1)
			{	
				for(i=0;i<32;i=i+2)
				{
				 cmd_dat[m] =(frame[(line*32)+1+i]>>8)&0xff;
				 m++;	
				 cmd_dat[m] =frame[(line*32)+1+i]&0xff;	
				 m++;	
				}
			}	
		}
	} 
	else if(frame[833] == 1)
	{
	  m=5;
	  for(line=0;line<24;line++)
		{
				
			if((line+2)%2==0)
			{	
				for(i=0;i<32;i=i+2)
				{
				 cmd_dat[m] =(frame[(line*32)+1+i]>>8)&0xff;
				 m++;	
				 cmd_dat[m] =frame[(line*32)+1+i]&0xff;	
				 m++;	
				}
			}
      if((line+2)%2==1)
			{	
				for(i=0;i<32;i=i+2)
				{
				 cmd_dat[m] =(frame[(line*32)+i]>>8)&0xff;
				 m++;	
				 cmd_dat[m] =frame[(line*32)+i]&0xff;	
				 m++;	
				}
			}			
		}			
	}
	
	for(i=768;i<834;i++)
	{
		cmd_dat[((i-768)<<1)+773] = (frame[i]>>8)&0xff;//1541+i-768
		cmd_dat[((i-768)<<1)+774] = frame[i]&0xff;
	}
	cmd_dat[905] = ((int16_t)(temperature * 100)>>8)&0xff;
	cmd_dat[906] = (int16_t)(temperature * 100)&0xff;
	
	cmd_dat[907] = cmd_dat[2];
	for(i=0;i<904;i++) cmd_dat[907] ^= cmd_dat[3+i];
	for(i=0;i<908;i++) uart2_send_byte(cmd_dat[i]);
#endif
}

static void response_e2p_defaultcal()
{
	int i;
	u16 len = 1664;//0x0680
	u8 cmd_dat[1670] = {0x23,0x23,0x85};
	cmd_dat[3] = (len>>8)&0xff;
	cmd_dat[4] = len&0xff;
	for(i=0;i<832;i++)
	{
		cmd_dat[5+2*i] = (eeMLX90640[i]>>8)&0xff;
		cmd_dat[5+2*i+1] = eeMLX90640[i]&0xff;
	}
	
	cmd_dat[1669] = cmd_dat[2];
	for(i=0;i<1666;i++) cmd_dat[1669] ^= cmd_dat[3+i];
	
	for(i=0;i<1670;i++) uart2_send_byte(cmd_dat[i]);
//	computstr( USART2,cmd_dat,ch);//�������ݵ�����2
	
}

static void response_set_value()
{
	u8 i;
	u8 baudRateIndex;
	u8 refreshIndex;
	u8 cmd_dat[8] = {0x23,0x23,0x87,0x00,0x02};
	
	baudRateIndex = data_flag[0];
	refreshIndex = data_flag[1];
	
	if(baudRateIndex >= BAUDINDEX)
	{
		cmd_dat[5] = 0xFF;
	}
	else
	{
		cmd_dat[5] = baudRateIndex;
//		EE_WriteVariable( ADDR_BAUD_SET, baudRateIndex );
//		while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET );
//		USART_ClearFlag(USART2,USART_FLAG_TC);
//		ChangeUSARTBaudRate( baudRateIndex + 1 );
	}
	
	if(refreshIndex >= REFRESHINDEX)
	{
		cmd_dat[6] = 0xFF;
	}
	else
	{
		cmd_dat[6] = refreshIndex;
//		EE_WriteVariable( ADDR_REFRESH_SET, refreshIndex );
		ChangeMLX90640RefreshRate( refreshIndex + 2 );
	}

	cmd_dat[7] = cmd_dat[2];
	cmd_dat[7] ^= cmd_dat[3];
	cmd_dat[7] ^= cmd_dat[4];
	cmd_dat[7] ^= cmd_dat[5];
	cmd_dat[7] ^= cmd_dat[6];
	
	for(i=0;i<8;i++) uart2_send_byte(cmd_dat[i]);
	
	while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET );
	USART_ClearFlag(USART2,USART_FLAG_TC);
	ChangeUSARTBaudRate( baudRateIndex + 1 );
}

static void response_recovery_defaultvalue()
{
	u8 i;
	u8 baudRateIndex;
	u8 refreshIndex;
	u8 cmd_dat[8] = {0x23,0x23,0x88,0x00,0x02};
	
	baudRateIndex = 4;
	cmd_dat[5] = baudRateIndex;
//	EE_WriteVariable( ADDR_BAUD_SET, baudRateIndex );
//	while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET );
//	USART_ClearFlag(USART2,USART_FLAG_TC);
//	ChangeUSARTBaudRate( baudRateIndex + 1 );

	refreshIndex = 2;
	cmd_dat[6] = refreshIndex;
//	EE_WriteVariable( ADDR_REFRESH_SET, refreshIndex );
	ChangeMLX90640RefreshRate( refreshIndex + 2 );

	cmd_dat[7] = cmd_dat[2];
	cmd_dat[7] ^= cmd_dat[3];
	cmd_dat[7] ^= cmd_dat[4];
	cmd_dat[7] ^= cmd_dat[5];
	cmd_dat[7] ^= cmd_dat[6];
	
	for(i=0;i<8;i++) uart2_send_byte(cmd_dat[i]);
	
	while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET );
	USART_ClearFlag(USART2,USART_FLAG_TC);
	ChangeUSARTBaudRate( baudRateIndex + 1 );
}

void NVIC_Config(void)
{
	NVIC_InitTypeDef  NVIC_InitStructure;
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	
	
	NVIC_InitStructure.NVIC_IRQChannel  = USART2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority  = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}

void IWDG_config(void)
{
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);

  /* IWDG counter clock: LSI/32 */
  IWDG_SetPrescaler(IWDG_Prescaler_32);

  /* Set counter reload value to obtain 250ms IWDG TimeOut.
     Counter Reload Value = 250ms/IWDG counter clock period
                          = 250ms / (LsiFreq/32)
                          = 0.25s / (LsiFreq/32)
                          = LsiFreq/(32 * 4)
                          = LsiFreq/128
   */
  IWDG_SetReload(LSIFREQ/128);

  /* Reload IWDG counter */
  IWDG_ReloadCounter();

  /* Enable IWDG (the LSI oscillator will be enabled by hardware) */
//  IWDG_Enable();
}

void GetDataFromEEPROM( void )
{
	uint16_t	getData;
	baudRateValueIndex = 5;//115200bps
	RefreshRateValueIndex = 4;//8Hz

#if 0	
	if( *(__IO uint16_t*) (EEPROM_START_ADDRESS + 4) == 0xFFFF )
	{
		baudRateValueIndex = 5;//115200bps
		RefreshRateValueIndex = 4;//8Hz
	}
	else
	{
		EE_ReadVariable(ADDR_BAUD_SET , &getData);
		baudRateValueIndex = getData + 1;
		
		EE_ReadVariable(ADDR_REFRESH_SET , &getData);
		RefreshRateValueIndex = getData + 2;
	}
#endif	
}

int main()
{	
	u16 i = 0;	
	int curr = 0;
	uint8_t TollingLedFlag = 0;
	
	NVIC_Config();
 	SysTick_Init();	
// 	delay_init();
	gpio_init();
//	usart2_init();
	
	
	/* Unlock the Flash Program Erase controller */
  FLASH_Unlock();
/* EEPROM Init */
  EE_Init();

	GetDataFromEEPROM();
	
	sysUARTHardwareInit();
	while( DS18B20_Init());	
	
	MLX90640_SetRefreshRate( MLX_I2C_ADDR, GetRefreshRate(RefreshRateValueIndex) );
	curr = MLX90640_GetRefreshRate(MLX_I2C_ADDR);
	//printf("RefreshRate_Set=%x,RefreshRate_Read=%x\r\n",RefreshRate,curr);
	MLX90640_SetChessMode(MLX_I2C_ADDR);
	MLX90640_DumpEE(MLX_I2C_ADDR, eeMLX90640);
	MLX90640_ExtractParameters(eeMLX90640, &mlx90640);
	
	for(i=0;i<3;i++)//��ȥ��ʼ֡
	{
			MLX90640_GetFrameData(MLX_I2C_ADDR, frame);
			delay_ms_1(5);
	}

	temperature=DS18B20_Get_Temp();
	IWDG_config();
	i = 0;
	while(1)
	{
		if(TollingLedFlag == 0)
		{
			TollingLedFlag = 1;
			STM_LED_ON;
//			DS18B20_DATA_OUT(1);
//			Delay_us(500);
		}
		else
		{
			TollingLedFlag = 0;
			STM_LED_OFF;
//			DS18B20_DATA_OUT(0);
//			Delay_us(500);
		}

		MLX90640_GetFrameData(MLX_I2C_ADDR, frame);
		response_ir_data();
		
		if(i == 30)//2000ms
		{
			i = 0;
			temperature=DS18B20_Get_Temp();
		}
//		printf("\r\n temperature %.1f\r\n",DS18B20_Get_Temp());	 
//			delay_ms_1(1000);
//		uart2_send_byte(frame[833]);
//		response_e2p_defaultcal();
//		CheckUartRxDMAFrame();

    data_rec_server();		
		if(receive_flag == 1)
		{
			switch(command_flag)
			{
				case 0x80://basic info
					response_basic_info();
					break;
				case 0x82://open led
					IR_LED_ON;
					response_led_on(0x01);
					break;
				case 0x83://close led
					IR_LED_OFF;
					response_led_off(0x01);
					break;
				case 0x85://get e2p calvalue
					response_e2p_defaultcal();
				break;
				case 0x87://set baud and refreshrate value
					response_set_value();
				break;
				case 0x88://set baud and refreshrate defaultvalue
					response_recovery_defaultvalue();
				break;
				
				default:
					break;
			}
			receive_flag = 0;
		}
		IWDG_ReloadCounter();
		i++;
	}
}

