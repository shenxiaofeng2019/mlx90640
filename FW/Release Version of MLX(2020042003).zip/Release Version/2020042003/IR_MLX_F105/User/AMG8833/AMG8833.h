/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _AMG8833_H_
#define _AMG8833_H_


#include "stm32f10x_gpio.h"
#include "sys.h"

#define IIC8_SCL_0 GPIOB->BRR=GPIO_Pin_6
#define IIC8_SCL_1 GPIOB->BSRR=GPIO_Pin_6
#define IIC8_SDA_0 GPIOB->BRR=GPIO_Pin_7
#define IIC8_SDA_1 GPIOB->BSRR=GPIO_Pin_7
#define IIC8_SDA_STATE (GPIOB->IDR&GPIO_Pin_7)

enum ENUM_IIC8_REPLY
{
  IIC8_NACK=0 ,
  IIC8_ACK=1
};

enum ENUM_IIC8_BUS_STATE
{
  IIC8_READY=0,
  IIC8_BUS_BUSY=1,
  IIC8_BUS_ERROR=2
};

extern u16 IRPixBuf[64];

float AMG8833_ReadThermistor(void);
void AMG8833_readPixelsF(float *buf, u8 size);
void AMG8833_readPixelsB(u16 *buf, u8 size);


float AMG8833_ReadTemp(void);
u8 Init_AMG8833(void);
u8 ShutDown_AMG8833(void);
u8 GetData_AMG8833(void);  //��ȡ�¶�ֵ
void AMG8833_readPixelsF( float *buf, u8 size);
void AMG8833_readPixelsB(u16 *buf, u8 size);



void IIC8_Delay(void);
void IIC8_Configuration(void);
unsigned char IIC8_START(void);
void IIC8_STOP(void);
unsigned char IIC8_SendByte(unsigned char Data);
unsigned char IIC8_ReceiveByte(void);
void IIC8_SendACK(void);
void IIC8_SendNACK(void);
extern u8 AMG8833_compare(float *buf, float *buf1);
//extern u8 AMG8833_read_stat();
//extern void AMG_reset_stat();
#endif

