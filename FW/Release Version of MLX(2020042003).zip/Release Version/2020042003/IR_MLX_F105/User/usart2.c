#include "sys.h"
#include "usart2.h"
#include <string.h>

u8 Uart2_buffer_Rx[UART2_BUFF_SIZE];
u8 data_from_server[UART2_BUFF_SIZE];
u8 Uart2_Rx_P;
u8 command_flag;//�յ������ݵ�������
u8 data_flag[5];

void usart2_init(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  USART_InitTypeDef USART_InitStructure;
	
	RCC_APB2PeriphClockCmd(	RCC_APB2Periph_GPIOA, ENABLE );
	RCC_APB1PeriphClockCmd(	RCC_APB1Periph_USART2, ENABLE );		
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate  = BOUNDRATE;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_WordLength  = USART_WordLength_8b;
  USART_InitStructure.USART_Parity  = USART_Parity_No;
  USART_InitStructure.USART_StopBits  = USART_StopBits_1;
	USART_InitStructure.USART_Mode  = USART_Mode_Rx|USART_Mode_Tx;
  USART_Init(USART2,&USART_InitStructure);
	
  USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);
  USART_Cmd(USART2,ENABLE);
	
}

void uart2_send_byte(uint8_t byte)
{
  USART_SendData(USART2, byte);
  while (!(USART2->SR & USART_FLAG_TXE));
}

//// /******************************************************************8
////  * @brief  ���ô��ڵķ��ͺͽ���16���������ַ���
////  * @param  ��
////  * @retval ��
////  *********************************************************************/

///*��ָ�����ڷ��͵����ֽ�����*/
// void computchar(USART_TypeDef* USARTx,u8 ch)
// {
//		/* �ȴ�������� */
//		while (USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
//	 
//	 /* ����һ���ֽ����ݵ�USART1 */
//		USART_SendData(USARTx, ch);
//	 /* �ȴ�������� */
//		while (USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
//	 
// }
// 
// /*��ָ�����ڷ���ָ�����ȵ�����*/
//  void computstr(USART_TypeDef* USARTx,u8 *ptr,u16 len)
// {
//	 u16 i;
//	 for(i=0;i<len;i++)
//	 {
//		computchar(USARTx,*ptr);
//    ptr++;		 
//	 }	  
// }
// /*��ָ�����ڷ����ַ���*/ 
// 
//   void computcstr(USART_TypeDef* USARTx,const char *ptr)
// {
//	 while((*ptr)!=0)
//	 {
//		computchar(USARTx,*ptr);
//    ptr++;	
//	 }		 
//	 
// }
#if 0
static u8 get_xor_code(frmFmt frm)
{
	u16 i;
	u8 temp = 0;
	temp = frm.CmdFlag;
	temp ^= frm.Len[0];
	temp ^= frm.Len[1];
	for(i=0;i<frmfmt.Length;i++) 
		temp ^= frm.Buf[i];
	
	return temp;
}

static void protocol_analysisc(u8 receive_dat)
{
	static u8 pret;
	static enum cmdStatus cmdStatus_tcp = startFlag;
	static u16 length = 0,N = 0;
		
	pret = receive_dat;

	switch (cmdStatus_tcp)
	{
		case startFlag:
			frmfmt.StartID[N++] = pret;
			if(N==2) {
				N=0;
				if((frmfmt.StartID[0]==0x23)&&(frmfmt.StartID[1]==0x23)) cmdStatus_tcp=cmdFlag;
			}
			break;
		case cmdFlag:	
			frmfmt.CmdFlag = pret;
			cmdStatus_tcp = lenFlag;
			break;
		case lenFlag:	
			frmfmt.Len[N++] = pret;
			if(N==2) {
				
				frmfmt.Length =  length = (frmfmt.Len[0]<<8)|(frmfmt.Len[1]);
				if(frmfmt.Length == 0) cmdStatus_tcp=verifyFlag; else cmdStatus_tcp=bufFlag;
				N=0; 
			}
			break;
		case bufFlag:	
			if(frmfmt.Length != 0)
			{
				frmfmt.Buf[N++] = pret;
				if(N==length) {
					N=0;
					cmdStatus_tcp = verifyFlag;
				}
			}
			break;
		case verifyFlag:
			if(pret == get_xor_code(frmfmt))
			//if(pret == 0)
			{
				frmfmt.XorCode = pret;
				cmdStatus_tcp = startFlag;
				receive_flag = 1;
				//printf("receive success!\r\n");
			}
			else
			{
				frmfmt.XorCode = pret;
				cmdStatus_tcp = startFlag;
				receive_flag = 0;
			}
			break;
		default:break;
	}
}

#endif

#if 1
void data_rec_server (void)
{
	u8 i;
	u8 m,p,q;
	i=0;
	while(i<Uart2_Rx_P)
	{
		 if((Uart2_buffer_Rx[i]==0x23)&&(Uart2_buffer_Rx[i+1]==0x23))	
		 {
				for(m=0;m<10;m++)
				{
					data_from_server[m]=Uart2_buffer_Rx[i];
					i++;
				}
				p=data_from_server[2];   //����xorУ��
				if( p == 0x87 )
				{
					for(q=2;q<6;q++)
					{
						p^=data_from_server[q+1];	
					}
					if(p==data_from_server[7])
					{
						command_flag=data_from_server[2];
						data_flag[0] = data_from_server[5];
						data_flag[1] = data_from_server[6];
						receive_flag=1;
						clean_rebuff2();	
					}
				}
				else
				{
					for(q=2;q<4;q++)
					{
						p^=data_from_server[q+1];	
					}
					if(p==data_from_server[5])
					{
						command_flag=data_from_server[2];
						receive_flag=1;
						clean_rebuff2();	
					}	
				}
		 }
		 else i++;				 
	}	 
}


//void USART2_IRQHandler() 
//{    
//	u8 temp;
//	if(USART_GetITStatus(USART2,USART_IT_RXNE) != RESET)  
//	{      
//		USART_ClearITPendingBit(USART2,USART_IT_RXNE);   
//		temp = USART_ReceiveData(USART2);    
//		protocol_analysisc(temp); 
//	}
//}
void USART2_IRQHandler() 
{    

		if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
					{ 	
						if(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) != RESET)
						{		
							USART_ClearITPendingBit(USART2,USART_IT_RXNE); //����жϱ�־
							Uart2_buffer_Rx[Uart2_Rx_P] = USART_ReceiveData(USART2);
							Uart2_Rx_P++; 
							if(Uart2_Rx_P>=UART2_BUFF_SIZE )
							 {	
								Uart2_Rx_P=0; 
							 }	 
//							sim800c_time2=0;          //���������	
//							if(Uart2_rx_Sta==0) Uart2_Rx_FLAG=0xA5;	 	//ʹ�ܶ�ʱ��2���ж� 
					  } 
			  	}
					if(USART_GetFlagStatus(USART2,USART_FLAG_ORE)==SET)//���
					{
						USART_ClearFlag(USART2,USART_FLAG_ORE); //��SR
						USART_ReceiveData(USART2);//��SD
					}
        	USART_ClearFlag(USART2,USART_FLAG_RXNE); 
	
}

//��ȡ���յ������ݺͳ���
char *get_rebuff2(uint8_t *len)
{
    *len = Uart2_Rx_P;
    return (char *)&Uart2_buffer_Rx;
}

void clean_rebuff2(void)
{
    Uart2_Rx_P = 0;
	  memset(Uart2_buffer_Rx,0,UART2_BUFF_SIZE);
}

#endif



