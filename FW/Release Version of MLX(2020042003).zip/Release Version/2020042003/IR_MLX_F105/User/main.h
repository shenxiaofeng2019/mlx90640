#ifndef __main_H
#define	__main_H

#include "stm32f10x.h"
#include "bsp_usart.h"
#include "obd.h"
#include "bsp_lsm303.h"
#include <stdio.h>

void sim800c_send_gps(void);
void sim800c_connect(void);

#endif /* __main_H */
