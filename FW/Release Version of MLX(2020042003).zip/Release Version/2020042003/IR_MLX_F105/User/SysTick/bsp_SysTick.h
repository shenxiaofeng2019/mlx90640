#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "stm32f10x.h"

void SysTick_Init(void);
void Delay_us(__IO u32 nTime);         // ��λ1us

void delay_us_1(u32 n);
void delay_ms_1(u32 n);

#define Delay_ms(x) Delay_us(1000*x)	 //��λms

#endif /* __SYSTICK_H */
